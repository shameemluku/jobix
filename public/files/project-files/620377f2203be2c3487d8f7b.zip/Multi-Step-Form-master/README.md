# Multi-Step Form
A Multi-Step Form is a single form with multiple steps to fill and there is also a progressbar.
![capture](https://user-images.githubusercontent.com/36005170/43359822-1ff17f80-92c7-11e8-87ba-f1aadc19a414.PNG)

# Tools:
```
  HTML
  CSS
  JavaScript
  jQuery
````

# License
This project is licensed under the Apache License - see the LICENSE.md file for details.

