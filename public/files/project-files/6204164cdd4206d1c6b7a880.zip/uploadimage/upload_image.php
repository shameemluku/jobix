<?php include('connection.php');

if(isset($_POST['submit']))
{
	if($_FILES['img_file']['size'] > 0)
	{
		$fileName = $_FILES['img_file']['name'];
		$ext = strtolower(pathinfo($fileName,PATHINFO_EXTENSION));
		if($ext=='jpg' || $ext=='jpeg' || $ext=='png')
		{
			$upload_path = 'uploads/'.$fileName;
			if(move_uploaded_file($_FILES['img_file']['tmp_name'], $upload_path))
			{
				$sql = "INSERT INTO `upload_images` (`img_path`) values ('$upload_path') ";
				$query  = mysqli_query($con,$sql);
				if($query==true)
				{
					header("location:index.php");
				}
				else
				{
					echo 'Database error';exit;
				}

			}
			else
			{
				echo 'Image upload error';exit;
			}

		}
		else
		{
			echo 'Uploaded file is not image';exit;
			exit;
		}

	}
	else
	{
		echo 'please select image file';exit;
	}
}