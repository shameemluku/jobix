<?php 
$con = mysqli_connect('localhost','root','','images');
if(mysqli_connect_errno())
{
	echo 'Error Database Connection';
	exit;
}