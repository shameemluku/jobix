<?php include('connection.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>UPload Image to database</title>
</head>
<body>
	<form method="post" enctype="multipart/form-data" action="upload_image.php">
		<input type="file" name="img_file" required>
		<input type="submit"  name="submit" value="Upload">
	</form>
	<p>Uploaded file List</p>
	<table border="1">
		<thead>
			<th>Sno.</th>
			<th>Image</th>
		</thead>
		<tbody>
			<?php $sql= "SELECT * FROM upload_images";
			$query = mysqli_query($con,$sql);
			$i=1;
			while($row = mysqli_fetch_assoc($query)) {
			 ?>
			
			<tr>
				<td><?=$i++?></td>
				<td>
					<img src="<?=$row['img_path']?>" width="100" >
				</td>
			</tr>
			<?php } ?>
		</tbody>
	</table>
</body>
</html>